from Prueba_tech.Entity.fifo import ArrayFIFO


def main():
    array = ArrayFIFO()
    # TODO: do some stuff with array


if __name__ == '__main__':
    main()
